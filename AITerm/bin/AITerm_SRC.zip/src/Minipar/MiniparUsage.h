// MiniparUsage.h

#ifndef __MINIPARUSAGE_H_
#define __MINIPARUSAGE_H_


void outputParsingResult(CSimpleMinipar Minipar);


#endif //__MINIPARUSAGE_H_